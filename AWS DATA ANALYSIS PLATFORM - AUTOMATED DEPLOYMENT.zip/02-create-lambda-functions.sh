#!/bin/bash

################################################################################
# AWS Data Analysis Platform - Lambda Functions Setup
# Phase 2: Create and Deploy Lambda Functions
################################################################################

set -e

# Load configuration
if [ ! -f /tmp/data-analysis-platform-config.json ]; then
    echo "❌ Error: Configuration file not found. Run 01-setup-foundation.sh first."
    exit 1
fi

CONFIG=$(cat /tmp/data-analysis-platform-config.json)
REGION=$(echo $CONFIG | jq -r '.region')
DATA_BUCKET=$(echo $CONFIG | jq -r '.data_bucket')
LAMBDA_UPLOAD_ROLE=$(echo $CONFIG | jq -r '.lambda_upload_role_arn')
LAMBDA_PROCESSOR_ROLE=$(echo $CONFIG | jq -r '.lambda_processor_role_arn')
LAMBDA_AI_ROLE=$(echo $CONFIG | jq -r '.lambda_ai_role_arn')
METADATA_TABLE=$(echo $CONFIG | jq -r '.metadata_table')
INSIGHTS_TABLE=$(echo $CONFIG | jq -r '.insights_table')
PROJECT_NAME=$(echo $CONFIG | jq -r '.project_name')

echo "=================================================="
echo "🚀 Creating Lambda Functions"
echo "=================================================="
echo ""

# Create working directory
mkdir -p /tmp/lambda-packages
cd /tmp/lambda-packages

################################################################################
# Lambda 1: Upload Handler
################################################################################

echo "📦 Creating Lambda 1: Upload Handler..."
mkdir -p upload-handler
cd upload-handler

cat > lambda_function.py << 'EOF'
import json
import boto3
import os
import hashlib
import time
from datetime import datetime
from urllib.parse import unquote_plus

s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')

DATA_BUCKET = os.environ['DATA_BUCKET']
METADATA_TABLE = os.environ['METADATA_TABLE']

def lambda_handler(event, context):
    """
    Handle file uploads from API Gateway
    Stores files in S3 raw/ folder and tracks metadata in DynamoDB
    """
    try:
        # Parse request
        if 'body' not in event:
            return {
                'statusCode': 400,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json'
                },
                'body': json.dumps({'error': 'No file data provided'})
            }
        
        # Get file data (assuming base64 encoded)
        import base64
        body = json.loads(event['body'])
        file_name = body.get('fileName', 'upload.csv')
        file_content = body.get('fileContent', '')
        file_type = body.get('fileType', 'text/csv')
        
        # Decode base64 content
        file_data = base64.b64decode(file_content)
        
        # Generate upload ID and hash
        upload_id = f"{int(time.time() * 1000)}-{hashlib.md5(file_name.encode()).hexdigest()[:8]}"
        file_hash = hashlib.md5(file_data).hexdigest()
        
        # Upload to S3
        s3_key = f"raw/{upload_id}/{file_name}"
        s3.put_object(
            Bucket=DATA_BUCKET,
            Key=s3_key,
            Body=file_data,
            ContentType=file_type,
            Metadata={
                'upload-id': upload_id,
                'file-hash': file_hash,
                'original-name': file_name
            }
        )
        
        # Store metadata in DynamoDB
        table = dynamodb.Table(METADATA_TABLE)
        table.put_item(
            Item={
                'upload_id': upload_id,
                'timestamp': int(time.time()),
                'file_name': file_name,
                'file_hash': file_hash,
                's3_key': s3_key,
                'file_size': len(file_data),
                'status': 'uploaded',
                'upload_date': datetime.utcnow().isoformat()
            }
        )
        
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'message': 'File uploaded successfully',
                'upload_id': upload_id,
                'file_name': file_name,
                's3_key': s3_key,
                'file_hash': file_hash
            })
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({'error': str(e)})
        }
EOF

# Create deployment package
zip -r ../upload-handler.zip .
cd ..

# Deploy Lambda
echo "Deploying Upload Handler Lambda..."
aws lambda create-function \
    --function-name ${PROJECT_NAME}-upload-handler \
    --runtime python3.11 \
    --role ${LAMBDA_UPLOAD_ROLE} \
    --handler lambda_function.lambda_handler \
    --zip-file fileb://upload-handler.zip \
    --timeout 30 \
    --memory-size 512 \
    --environment "Variables={DATA_BUCKET=${DATA_BUCKET},METADATA_TABLE=${METADATA_TABLE}}" \
    --region ${REGION} \
    2>/dev/null || aws lambda update-function-code \
        --function-name ${PROJECT_NAME}-upload-handler \
        --zip-file fileb://upload-handler.zip \
        --region ${REGION}

# Update environment variables in case of update
aws lambda update-function-configuration \
    --function-name ${PROJECT_NAME}-upload-handler \
    --environment "Variables={DATA_BUCKET=${DATA_BUCKET},METADATA_TABLE=${METADATA_TABLE}}" \
    --region ${REGION} > /dev/null

echo "✅ Upload Handler Lambda deployed!"
echo ""

################################################################################
# Lambda 2: Data Processor (CSV to Parquet)
################################################################################

echo "📦 Creating Lambda 2: Data Processor..."
mkdir -p data-processor
cd data-processor

cat > lambda_function.py << 'EOF'
import json
import boto3
import os
import io
import csv
from datetime import datetime
from urllib.parse import unquote_plus

s3 = boto3.client('s3')
glue = boto3.client('glue')
dynamodb = boto3.resource('dynamodb')

DATA_BUCKET = os.environ['DATA_BUCKET']
GLUE_DATABASE = os.environ['GLUE_DATABASE']
METADATA_TABLE = os.environ['METADATA_TABLE']

def lambda_handler(event, context):
    """
    Process uploaded files: CSV to Parquet conversion
    Triggered by S3 events on raw/ folder
    """
    try:
        # Get S3 event details
        for record in event['Records']:
            bucket = record['s3']['bucket']['name']
            key = unquote_plus(record['s3']['object']['key'])
            
            # Skip if not in raw/ folder
            if not key.startswith('raw/'):
                continue
            
            print(f"Processing file: {key}")
            
            # Get file from S3
            response = s3.get_object(Bucket=bucket, Key=key)
            file_content = response['Body'].read()
            
            # Extract upload_id from key (format: raw/upload_id/filename)
            parts = key.split('/')
            upload_id = parts[1] if len(parts) > 1 else 'unknown'
            file_name = parts[-1]
            
            # Determine file type and process
            if file_name.endswith('.csv'):
                processed_key = process_csv(bucket, key, file_content, upload_id)
            elif file_name.endswith('.json'):
                processed_key = process_json(bucket, key, file_content, upload_id)
            else:
                # For now, just copy to processed
                processed_key = key.replace('raw/', 'processed/')
                s3.put_object(
                    Bucket=bucket,
                    Key=processed_key,
                    Body=file_content
                )
            
            # Update metadata
            table = dynamodb.Table(METADATA_TABLE)
            table.update_item(
                Key={'upload_id': upload_id, 'timestamp': int(response['Metadata'].get('timestamp', 0))},
                UpdateExpression='SET #status = :status, processed_key = :key, processed_date = :date',
                ExpressionAttributeNames={'#status': 'status'},
                ExpressionAttributeValues={
                    ':status': 'processed',
                    ':key': processed_key,
                    ':date': datetime.utcnow().isoformat()
                }
            )
            
            print(f"✅ Processed: {processed_key}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Processing complete'})
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        raise

def process_csv(bucket, key, content, upload_id):
    """Convert CSV to optimized format and store"""
    # For MVP, we'll just copy CSV to processed folder
    # In production, you'd use pandas/pyarrow to convert to Parquet
    processed_key = key.replace('raw/', 'processed/')
    
    # Parse CSV to validate
    csv_data = content.decode('utf-8')
    reader = csv.reader(io.StringIO(csv_data))
    rows = list(reader)
    
    if len(rows) == 0:
        raise ValueError("Empty CSV file")
    
    # Store processed file
    s3.put_object(
        Bucket=bucket,
        Key=processed_key,
        Body=content,
        Metadata={
            'row-count': str(len(rows) - 1),  # Subtract header
            'column-count': str(len(rows[0]) if rows else 0),
            'upload-id': upload_id
        }
    )
    
    return processed_key

def process_json(bucket, key, content, upload_id):
    """Process JSON files"""
    processed_key = key.replace('raw/', 'processed/')
    
    # Validate JSON
    json.loads(content.decode('utf-8'))
    
    # Store processed file
    s3.put_object(
        Bucket=bucket,
        Key=processed_key,
        Body=content,
        Metadata={'upload-id': upload_id}
    )
    
    return processed_key
EOF

# Create deployment package
zip -r ../data-processor.zip .
cd ..

# Deploy Lambda
echo "Deploying Data Processor Lambda..."
aws lambda create-function \
    --function-name ${PROJECT_NAME}-data-processor \
    --runtime python3.11 \
    --role ${LAMBDA_PROCESSOR_ROLE} \
    --handler lambda_function.lambda_handler \
    --zip-file fileb://data-processor.zip \
    --timeout 60 \
    --memory-size 1024 \
    --environment "Variables={DATA_BUCKET=${DATA_BUCKET},GLUE_DATABASE=data-analysis-platform_catalog,METADATA_TABLE=${METADATA_TABLE}}" \
    --region ${REGION} \
    2>/dev/null || aws lambda update-function-code \
        --function-name ${PROJECT_NAME}-data-processor \
        --zip-file fileb://data-processor.zip \
        --region ${REGION}

# Update configuration
aws lambda update-function-configuration \
    --function-name ${PROJECT_NAME}-data-processor \
    --environment "Variables={DATA_BUCKET=${DATA_BUCKET},GLUE_DATABASE=data-analysis-platform_catalog,METADATA_TABLE=${METADATA_TABLE}}" \
    --region ${REGION} > /dev/null

echo "✅ Data Processor Lambda deployed!"
echo ""

# Configure S3 trigger
echo "🔗 Configuring S3 Event Trigger..."

# Add Lambda permission for S3 to invoke
aws lambda add-permission \
    --function-name ${PROJECT_NAME}-data-processor \
    --statement-id s3-trigger-permission \
    --action lambda:InvokeFunction \
    --principal s3.amazonaws.com \
    --source-arn arn:aws:s3:::${DATA_BUCKET} \
    --region ${REGION} \
    2>/dev/null || echo "Permission already exists"

# Configure S3 notification
cat > /tmp/s3-notification.json << EOF
{
    "LambdaFunctionConfigurations": [
        {
            "Id": "ProcessRawFiles",
            "LambdaFunctionArn": "arn:aws:lambda:${REGION}:$(echo $CONFIG | jq -r '.account_id'):function:${PROJECT_NAME}-data-processor",
            "Events": ["s3:ObjectCreated:*"],
            "Filter": {
                "Key": {
                    "FilterRules": [
                        {
                            "Name": "prefix",
                            "Value": "raw/"
                        }
                    ]
                }
            }
        }
    ]
}
EOF

aws s3api put-bucket-notification-configuration \
    --bucket ${DATA_BUCKET} \
    --notification-configuration file:///tmp/s3-notification.json

echo "✅ S3 trigger configured!"
echo ""

################################################################################
# Lambda 3: AI Analyzer (Bedrock Integration)
################################################################################

echo "📦 Creating Lambda 3: AI Analyzer..."
mkdir -p ai-analyzer
cd ai-analyzer

cat > lambda_function.py << 'EOF'
import json
import boto3
import os
import hashlib
from datetime import datetime

s3 = boto3.client('s3')
bedrock = boto3.client('bedrock-runtime')
dynamodb = boto3.resource('dynamodb')

DATA_BUCKET = os.environ['DATA_BUCKET']
INSIGHTS_TABLE = os.environ['INSIGHTS_TABLE']

def lambda_handler(event, context):
    """
    Analyze processed data files using Amazon Bedrock
    Returns AI-generated insights
    """
    try:
        # Parse input
        if 'body' in event:
            body = json.loads(event['body'])
            s3_key = body.get('s3_key')
            upload_id = body.get('upload_id')
        else:
            # Direct invocation
            s3_key = event.get('s3_key')
            upload_id = event.get('upload_id')
        
        if not s3_key:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'No s3_key provided'})
            }
        
        # Check cache first
        file_hash = hashlib.md5(s3_key.encode()).hexdigest()
        table = dynamodb.Table(INSIGHTS_TABLE)
        
        try:
            response = table.get_item(Key={'file_hash': file_hash})
            if 'Item' in response:
                # Return cached insights
                print("✅ Returning cached insights")
                return {
                    'statusCode': 200,
                    'headers': {
                        'Access-Control-Allow-Origin': '*',
                        'Content-Type': 'application/json'
                    },
                    'body': json.dumps({
                        'insights': response['Item']['insights'],
                        'cached': True
                    })
                }
        except Exception as e:
            print(f"Cache check failed: {e}")
        
        # Get file from S3
        response = s3.get_object(Bucket=DATA_BUCKET, Key=s3_key)
        file_content = response['Body'].read().decode('utf-8')
        
        # Truncate if too large (Bedrock has limits)
        if len(file_content) > 50000:
            file_content = file_content[:50000] + "\n... (truncated)"
        
        # Prepare Bedrock request
        prompt = f"""You are a data analyst. Analyze this dataset and provide 3-5 key insights.

Dataset preview:
{file_content}

Provide your analysis in JSON format:
{{
    "summary": "Brief overview of the data",
    "key_insights": [
        "Insight 1",
        "Insight 2",
        "Insight 3"
    ],
    "data_quality": "Assessment of data quality",
    "recommendations": [
        "Recommendation 1",
        "Recommendation 2"
    ]
}}
"""

        # Call Bedrock (using Claude model)
        bedrock_body = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 2000,
            "messages": [
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        })
        
        try:
            bedrock_response = bedrock.invoke_model(
                modelId='anthropic.claude-3-haiku-20240307-v1:0',
                body=bedrock_body
            )
            
            response_body = json.loads(bedrock_response['body'].read())
            insights_text = response_body['content'][0]['text']
            
            # Extract JSON from response
            try:
                # Try to parse as JSON
                insights = json.loads(insights_text)
            except:
                # If not valid JSON, wrap in structure
                insights = {
                    "summary": "Analysis complete",
                    "key_insights": [insights_text],
                    "data_quality": "Unknown",
                    "recommendations": []
                }
            
        except Exception as e:
            print(f"Bedrock error: {e}")
            # Fallback insights if Bedrock fails
            insights = {
                "summary": "Basic data analysis",
                "key_insights": [
                    "Data file processed successfully",
                    f"File size: {len(file_content)} bytes",
                    "AI analysis temporarily unavailable"
                ],
                "data_quality": "Unknown - manual review recommended",
                "recommendations": [
                    "Enable Bedrock access in eu-central-1",
                    "Check IAM permissions for Bedrock"
                ]
            }
        
        # Cache results
        table.put_item(
            Item={
                'file_hash': file_hash,
                'insights': insights,
                'analyzed_date': datetime.utcnow().isoformat(),
                'ttl': int(datetime.utcnow().timestamp()) + 86400  # 24 hour cache
            }
        )
        
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'insights': insights,
                'cached': False
            })
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({'error': str(e)})
        }
EOF

# Create deployment package
zip -r ../ai-analyzer.zip .
cd ..

# Deploy Lambda
echo "Deploying AI Analyzer Lambda..."
aws lambda create-function \
    --function-name ${PROJECT_NAME}-ai-analyzer \
    --runtime python3.11 \
    --role ${LAMBDA_AI_ROLE} \
    --handler lambda_function.lambda_handler \
    --zip-file fileb://ai-analyzer.zip \
    --timeout 60 \
    --memory-size 512 \
    --environment "Variables={DATA_BUCKET=${DATA_BUCKET},INSIGHTS_TABLE=${INSIGHTS_TABLE}}" \
    --region ${REGION} \
    2>/dev/null || aws lambda update-function-code \
        --function-name ${PROJECT_NAME}-ai-analyzer \
        --zip-file fileb://ai-analyzer.zip \
        --region ${REGION}

# Update configuration
aws lambda update-function-configuration \
    --function-name ${PROJECT_NAME}-ai-analyzer \
    --environment "Variables={DATA_BUCKET=${DATA_BUCKET},INSIGHTS_TABLE=${INSIGHTS_TABLE}}" \
    --region ${REGION} > /dev/null

echo "✅ AI Analyzer Lambda deployed!"
echo ""

echo "=================================================="
echo "✅ All Lambda Functions Deployed!"
echo "=================================================="
echo ""
echo "📋 Summary:"
echo "  ✓ ${PROJECT_NAME}-upload-handler (API Gateway trigger)"
echo "  ✓ ${PROJECT_NAME}-data-processor (S3 event trigger)"
echo "  ✓ ${PROJECT_NAME}-ai-analyzer (Manual/API invoke)"
echo ""
echo "🎯 Next Step: Run 03-setup-api-gateway.sh"
echo "=================================================="
