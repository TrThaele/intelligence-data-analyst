#!/bin/bash

################################################################################
# AWS Data Analysis Platform - API Gateway Setup
# Phase 3: Create REST API with Lambda Integration
################################################################################

set -e

# Load configuration
if [ ! -f /tmp/data-analysis-platform-config.json ]; then
    echo "❌ Error: Configuration file not found."
    exit 1
fi

CONFIG=$(cat /tmp/data-analysis-platform-config.json)
REGION=$(echo $CONFIG | jq -r '.region')
ACCOUNT_ID=$(echo $CONFIG | jq -r '.account_id')
PROJECT_NAME=$(echo $CONFIG | jq -r '.project_name')

echo "=================================================="
echo "🚀 Creating API Gateway"
echo "=================================================="
echo ""

# Create REST API
echo "📡 Creating REST API..."
API_ID=$(aws apigateway create-rest-api \
    --name "${PROJECT_NAME}-api" \
    --description "API for Data Analysis Platform" \
    --endpoint-configuration types=REGIONAL \
    --region ${REGION} \
    --output text \
    --query 'id' 2>/dev/null)

if [ -z "$API_ID" ]; then
    # API might already exist, get it
    API_ID=$(aws apigateway get-rest-apis \
        --region ${REGION} \
        --query "items[?name=='${PROJECT_NAME}-api'].id" \
        --output text)
fi

echo "API ID: ${API_ID}"

# Get root resource ID
ROOT_ID=$(aws apigateway get-resources \
    --rest-api-id ${API_ID} \
    --region ${REGION} \
    --query 'items[?path==`/`].id' \
    --output text)

echo "Root Resource ID: ${ROOT_ID}"
echo ""

################################################################################
# Create /upload endpoint
################################################################################

echo "📝 Creating /upload resource..."

# Create resource
UPLOAD_RESOURCE_ID=$(aws apigateway create-resource \
    --rest-api-id ${API_ID} \
    --parent-id ${ROOT_ID} \
    --path-part upload \
    --region ${REGION} \
    --output text \
    --query 'id' 2>/dev/null)

if [ -z "$UPLOAD_RESOURCE_ID" ]; then
    UPLOAD_RESOURCE_ID=$(aws apigateway get-resources \
        --rest-api-id ${API_ID} \
        --region ${REGION} \
        --query "items[?path=='/upload'].id" \
        --output text)
fi

echo "Upload Resource ID: ${UPLOAD_RESOURCE_ID}"

# Create POST method
echo "Creating POST method..."
aws apigateway put-method \
    --rest-api-id ${API_ID} \
    --resource-id ${UPLOAD_RESOURCE_ID} \
    --http-method POST \
    --authorization-type NONE \
    --region ${REGION} \
    2>/dev/null || echo "Method already exists"

# Configure Lambda integration
LAMBDA_UPLOAD_ARN="arn:aws:lambda:${REGION}:${ACCOUNT_ID}:function:${PROJECT_NAME}-upload-handler"

aws apigateway put-integration \
    --rest-api-id ${API_ID} \
    --resource-id ${UPLOAD_RESOURCE_ID} \
    --http-method POST \
    --type AWS_PROXY \
    --integration-http-method POST \
    --uri "arn:aws:apigateway:${REGION}:lambda:path/2015-03-31/functions/${LAMBDA_UPLOAD_ARN}/invocations" \
    --region ${REGION} \
    2>/dev/null || echo "Integration already exists"

# Add Lambda permission
aws lambda add-permission \
    --function-name ${PROJECT_NAME}-upload-handler \
    --statement-id apigateway-upload-invoke \
    --action lambda:InvokeFunction \
    --principal apigateway.amazonaws.com \
    --source-arn "arn:aws:execute-api:${REGION}:${ACCOUNT_ID}:${API_ID}/*/*/upload" \
    --region ${REGION} \
    2>/dev/null || echo "Permission already exists"

# Enable CORS for POST
aws apigateway put-method-response \
    --rest-api-id ${API_ID} \
    --resource-id ${UPLOAD_RESOURCE_ID} \
    --http-method POST \
    --status-code 200 \
    --response-parameters '{"method.response.header.Access-Control-Allow-Origin": false}' \
    --region ${REGION} \
    2>/dev/null || echo "Method response already exists"

echo "✅ /upload endpoint created!"
echo ""

################################################################################
# Create /analyze endpoint
################################################################################

echo "📝 Creating /analyze resource..."

ANALYZE_RESOURCE_ID=$(aws apigateway create-resource \
    --rest-api-id ${API_ID} \
    --parent-id ${ROOT_ID} \
    --path-part analyze \
    --region ${REGION} \
    --output text \
    --query 'id' 2>/dev/null)

if [ -z "$ANALYZE_RESOURCE_ID" ]; then
    ANALYZE_RESOURCE_ID=$(aws apigateway get-resources \
        --rest-api-id ${API_ID} \
        --region ${REGION} \
        --query "items[?path=='/analyze'].id" \
        --output text)
fi

echo "Analyze Resource ID: ${ANALYZE_RESOURCE_ID}"

# Create POST method
aws apigateway put-method \
    --rest-api-id ${API_ID} \
    --resource-id ${ANALYZE_RESOURCE_ID} \
    --http-method POST \
    --authorization-type NONE \
    --region ${REGION} \
    2>/dev/null || echo "Method already exists"

# Configure Lambda integration
LAMBDA_AI_ARN="arn:aws:lambda:${REGION}:${ACCOUNT_ID}:function:${PROJECT_NAME}-ai-analyzer"

aws apigateway put-integration \
    --rest-api-id ${API_ID} \
    --resource-id ${ANALYZE_RESOURCE_ID} \
    --http-method POST \
    --type AWS_PROXY \
    --integration-http-method POST \
    --uri "arn:aws:apigateway:${REGION}:lambda:path/2015-03-31/functions/${LAMBDA_AI_ARN}/invocations" \
    --region ${REGION} \
    2>/dev/null || echo "Integration already exists"

# Add Lambda permission
aws lambda add-permission \
    --function-name ${PROJECT_NAME}-ai-analyzer \
    --statement-id apigateway-analyze-invoke \
    --action lambda:InvokeFunction \
    --principal apigateway.amazonaws.com \
    --source-arn "arn:aws:execute-api:${REGION}:${ACCOUNT_ID}:${API_ID}/*/*/analyze" \
    --region ${REGION} \
    2>/dev/null || echo "Permission already exists"

# Enable CORS
aws apigateway put-method-response \
    --rest-api-id ${API_ID} \
    --resource-id ${ANALYZE_RESOURCE_ID} \
    --http-method POST \
    --status-code 200 \
    --response-parameters '{"method.response.header.Access-Control-Allow-Origin": false}' \
    --region ${REGION} \
    2>/dev/null || echo "Method response already exists"

echo "✅ /analyze endpoint created!"
echo ""

################################################################################
# Add CORS support (OPTIONS methods)
################################################################################

echo "🌐 Configuring CORS..."

# Function to add CORS to a resource
add_cors() {
    local RESOURCE_ID=$1
    local PATH=$2
    
    echo "Adding CORS to ${PATH}..."
    
    # Create OPTIONS method
    aws apigateway put-method \
        --rest-api-id ${API_ID} \
        --resource-id ${RESOURCE_ID} \
        --http-method OPTIONS \
        --authorization-type NONE \
        --region ${REGION} \
        2>/dev/null || echo "OPTIONS method exists"
    
    # Add mock integration
    aws apigateway put-integration \
        --rest-api-id ${API_ID} \
        --resource-id ${RESOURCE_ID} \
        --http-method OPTIONS \
        --type MOCK \
        --request-templates '{"application/json": "{\"statusCode\": 200}"}' \
        --region ${REGION} \
        2>/dev/null || echo "Integration exists"
    
    # Add method response
    aws apigateway put-method-response \
        --rest-api-id ${API_ID} \
        --resource-id ${RESOURCE_ID} \
        --http-method OPTIONS \
        --status-code 200 \
        --response-parameters '{
            "method.response.header.Access-Control-Allow-Headers": false,
            "method.response.header.Access-Control-Allow-Methods": false,
            "method.response.header.Access-Control-Allow-Origin": false
        }' \
        --region ${REGION} \
        2>/dev/null || echo "Method response exists"
    
    # Add integration response
    aws apigateway put-integration-response \
        --rest-api-id ${API_ID} \
        --resource-id ${RESOURCE_ID} \
        --http-method OPTIONS \
        --status-code 200 \
        --response-parameters '{
            "method.response.header.Access-Control-Allow-Headers": "'"'"'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token'"'"'",
            "method.response.header.Access-Control-Allow-Methods": "'"'"'GET,POST,PUT,DELETE,OPTIONS'"'"'",
            "method.response.header.Access-Control-Allow-Origin": "'"'"'*'"'"'"
        }' \
        --region ${REGION} \
        2>/dev/null || echo "Integration response exists"
}

# Add CORS to all resources
add_cors ${UPLOAD_RESOURCE_ID} "/upload"
add_cors ${ANALYZE_RESOURCE_ID} "/analyze"

echo "✅ CORS configured!"
echo ""

################################################################################
# Deploy API
################################################################################

echo "🚀 Deploying API..."

# Create deployment
DEPLOYMENT_ID=$(aws apigateway create-deployment \
    --rest-api-id ${API_ID} \
    --stage-name prod \
    --stage-description "Production deployment" \
    --description "Initial deployment" \
    --region ${REGION} \
    --output text \
    --query 'id')

echo "Deployment ID: ${DEPLOYMENT_ID}"

# Get API endpoint
API_ENDPOINT="https://${API_ID}.execute-api.${REGION}.amazonaws.com/prod"

echo ""
echo "=================================================="
echo "✅ API Gateway Deployed!"
echo "=================================================="
echo ""
echo "📋 API Details:"
echo "  API ID: ${API_ID}"
echo "  Endpoint: ${API_ENDPOINT}"
echo ""
echo "📡 Endpoints:"
echo "  Upload:  ${API_ENDPOINT}/upload"
echo "  Analyze: ${API_ENDPOINT}/analyze"
echo ""

# Save API endpoint to config
CONFIG_UPDATED=$(echo $CONFIG | jq ". + {api_id: \"${API_ID}\", api_endpoint: \"${API_ENDPOINT}\"}")
echo "$CONFIG_UPDATED" > /tmp/data-analysis-platform-config.json

echo "Configuration updated!"
echo ""
echo "🎯 Next Step: Test the API or run 04-setup-monitoring.sh"
echo "=================================================="
