#!/bin/bash

################################################################################
# AWS Data Analysis Platform - Foundation Setup
# Region: eu-central-1
# Phase 1: S3 Buckets, IAM Roles, and Core Infrastructure
################################################################################

set -e  # Exit on any error

# Configuration
REGION="eu-central-1"
ACCOUNT_ID="360783618622"
PROJECT_NAME="data-analysis-platform"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)

# Generate unique bucket names (S3 bucket names must be globally unique)
DATA_BUCKET="${PROJECT_NAME}-data-${ACCOUNT_ID}"
FRONTEND_BUCKET="${PROJECT_NAME}-frontend-${ACCOUNT_ID}"

echo "=================================================="
echo "🚀 AWS Data Analysis Platform - Foundation Setup"
echo "=================================================="
echo "Region: ${REGION}"
echo "Account: ${ACCOUNT_ID}"
echo "Timestamp: ${TIMESTAMP}"
echo "=================================================="
echo ""

# Step 1: Create S3 Buckets
echo "📦 Step 1: Creating S3 Buckets..."
echo ""

# Data Lake Bucket (Raw + Processed)
echo "Creating data bucket: ${DATA_BUCKET}"
aws s3api create-bucket \
    --bucket ${DATA_BUCKET} \
    --region ${REGION} \
    --create-bucket-configuration LocationConstraint=${REGION} \
    2>/dev/null || echo "Bucket ${DATA_BUCKET} already exists"

# Enable versioning
aws s3api put-bucket-versioning \
    --bucket ${DATA_BUCKET} \
    --versioning-configuration Status=Enabled

# Enable encryption
aws s3api put-bucket-encryption \
    --bucket ${DATA_BUCKET} \
    --server-side-encryption-configuration '{
        "Rules": [{
            "ApplyServerSideEncryptionByDefault": {
                "SSEAlgorithm": "AES256"
            }
        }]
    }'

# Create folder structure
echo "Creating folder structure in data bucket..."
aws s3api put-object --bucket ${DATA_BUCKET} --key raw/
aws s3api put-object --bucket ${DATA_BUCKET} --key processed/
aws s3api put-object --bucket ${DATA_BUCKET} --key temp/

# Frontend Bucket
echo "Creating frontend bucket: ${FRONTEND_BUCKET}"
aws s3api create-bucket \
    --bucket ${FRONTEND_BUCKET} \
    --region ${REGION} \
    --create-bucket-configuration LocationConstraint=${REGION} \
    2>/dev/null || echo "Bucket ${FRONTEND_BUCKET} already exists"

# Configure for static website hosting
aws s3 website s3://${FRONTEND_BUCKET}/ \
    --index-document index.html \
    --error-document error.html

echo "✅ S3 Buckets created successfully!"
echo ""

# Step 2: Create IAM Roles for Lambda Functions
echo "🔐 Step 2: Creating IAM Roles..."
echo ""

# Lambda Execution Role for Upload Handler
echo "Creating Lambda Upload Handler Role..."
cat > /tmp/lambda-upload-trust-policy.json << 'EOF'
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "lambda.amazonaws.com"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
EOF

aws iam create-role \
    --role-name ${PROJECT_NAME}-lambda-upload-role \
    --assume-role-policy-document file:///tmp/lambda-upload-trust-policy.json \
    2>/dev/null || echo "Role already exists"

# Attach policies
aws iam attach-role-policy \
    --role-name ${PROJECT_NAME}-lambda-upload-role \
    --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole

# Create inline policy for S3 access
cat > /tmp/lambda-upload-s3-policy.json << EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:PutObject",
        "s3:GetObject",
        "s3:DeleteObject"
      ],
      "Resource": "arn:aws:s3:::${DATA_BUCKET}/*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "s3:ListBucket"
      ],
      "Resource": "arn:aws:s3:::${DATA_BUCKET}"
    }
  ]
}
EOF

aws iam put-role-policy \
    --role-name ${PROJECT_NAME}-lambda-upload-role \
    --policy-name S3AccessPolicy \
    --policy-document file:///tmp/lambda-upload-s3-policy.json

echo "✅ Lambda Upload Role created!"

# Lambda Execution Role for Data Processor
echo "Creating Lambda Data Processor Role..."
aws iam create-role \
    --role-name ${PROJECT_NAME}-lambda-processor-role \
    --assume-role-policy-document file:///tmp/lambda-upload-trust-policy.json \
    2>/dev/null || echo "Role already exists"

aws iam attach-role-policy \
    --role-name ${PROJECT_NAME}-lambda-processor-role \
    --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole

# Create inline policy for S3 and Glue access
cat > /tmp/lambda-processor-policy.json << EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject",
        "s3:DeleteObject"
      ],
      "Resource": [
        "arn:aws:s3:::${DATA_BUCKET}/*"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "s3:ListBucket"
      ],
      "Resource": "arn:aws:s3:::${DATA_BUCKET}"
    },
    {
      "Effect": "Allow",
      "Action": [
        "glue:GetTable",
        "glue:CreateTable",
        "glue:UpdateTable",
        "glue:GetDatabase",
        "glue:CreateDatabase"
      ],
      "Resource": "*"
    }
  ]
}
EOF

aws iam put-role-policy \
    --role-name ${PROJECT_NAME}-lambda-processor-role \
    --policy-name S3GlueAccessPolicy \
    --policy-document file:///tmp/lambda-processor-policy.json

echo "✅ Lambda Processor Role created!"

# Lambda Execution Role for AI Analyzer
echo "Creating Lambda AI Analyzer Role..."
aws iam create-role \
    --role-name ${PROJECT_NAME}-lambda-ai-role \
    --assume-role-policy-document file:///tmp/lambda-upload-trust-policy.json \
    2>/dev/null || echo "Role already exists"

aws iam attach-role-policy \
    --role-name ${PROJECT_NAME}-lambda-ai-role \
    --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole

# Create inline policy for S3, DynamoDB, and Bedrock access
cat > /tmp/lambda-ai-policy.json << EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetObject"
      ],
      "Resource": "arn:aws:s3:::${DATA_BUCKET}/*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "dynamodb:PutItem",
        "dynamodb:GetItem",
        "dynamodb:Query",
        "dynamodb:UpdateItem"
      ],
      "Resource": "arn:aws:dynamodb:${REGION}:${ACCOUNT_ID}:table/${PROJECT_NAME}-*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "bedrock:InvokeModel"
      ],
      "Resource": "*"
    }
  ]
}
EOF

aws iam put-role-policy \
    --role-name ${PROJECT_NAME}-lambda-ai-role \
    --policy-name S3DynamoDBBedrockAccessPolicy \
    --policy-document file:///tmp/lambda-ai-policy.json

echo "✅ Lambda AI Role created!"
echo ""

# Step 3: Create DynamoDB Tables
echo "🗄️  Step 3: Creating DynamoDB Tables..."
echo ""

# Metadata Table
echo "Creating metadata table..."
aws dynamodb create-table \
    --table-name ${PROJECT_NAME}-metadata \
    --attribute-definitions \
        AttributeName=upload_id,AttributeType=S \
        AttributeName=timestamp,AttributeType=N \
    --key-schema \
        AttributeName=upload_id,KeyType=HASH \
        AttributeName=timestamp,KeyType=RANGE \
    --billing-mode PAY_PER_REQUEST \
    --region ${REGION} \
    2>/dev/null || echo "Table already exists"

# AI Insights Cache Table
echo "Creating AI insights cache table..."
aws dynamodb create-table \
    --table-name ${PROJECT_NAME}-ai-insights \
    --attribute-definitions \
        AttributeName=file_hash,AttributeType=S \
    --key-schema \
        AttributeName=file_hash,KeyType=HASH \
    --billing-mode PAY_PER_REQUEST \
    --region ${REGION} \
    2>/dev/null || echo "Table already exists"

echo "✅ DynamoDB tables created!"
echo ""

# Step 4: Create Glue Database
echo "🔧 Step 4: Creating Glue Data Catalog..."
echo ""

aws glue create-database \
    --database-input "{
        \"Name\": \"${PROJECT_NAME}_catalog\",
        \"Description\": \"Data catalog for uploaded datasets\"
    }" \
    --region ${REGION} \
    2>/dev/null || echo "Database already exists"

echo "✅ Glue database created!"
echo ""

# Step 5: Save Configuration
echo "💾 Step 5: Saving Configuration..."
echo ""

cat > /tmp/${PROJECT_NAME}-config.json << EOF
{
  "region": "${REGION}",
  "account_id": "${ACCOUNT_ID}",
  "project_name": "${PROJECT_NAME}",
  "data_bucket": "${DATA_BUCKET}",
  "frontend_bucket": "${FRONTEND_BUCKET}",
  "lambda_upload_role_arn": "arn:aws:iam::${ACCOUNT_ID}:role/${PROJECT_NAME}-lambda-upload-role",
  "lambda_processor_role_arn": "arn:aws:iam::${ACCOUNT_ID}:role/${PROJECT_NAME}-lambda-processor-role",
  "lambda_ai_role_arn": "arn:aws:iam::${ACCOUNT_ID}:role/${PROJECT_NAME}-lambda-ai-role",
  "metadata_table": "${PROJECT_NAME}-metadata",
  "insights_table": "${PROJECT_NAME}-ai-insights",
  "glue_database": "${PROJECT_NAME}_catalog"
}
EOF

echo "Configuration saved to: /tmp/${PROJECT_NAME}-config.json"
cat /tmp/${PROJECT_NAME}-config.json
echo ""

# Step 6: Wait for IAM roles to propagate
echo "⏳ Step 6: Waiting for IAM roles to propagate (10 seconds)..."
sleep 10
echo "✅ IAM roles ready!"
echo ""

echo "=================================================="
echo "✅ Foundation Setup Complete!"
echo "=================================================="
echo ""
echo "📋 Summary:"
echo "  ✓ S3 Buckets: ${DATA_BUCKET}, ${FRONTEND_BUCKET}"
echo "  ✓ IAM Roles: 3 Lambda execution roles created"
echo "  ✓ DynamoDB: 2 tables created"
echo "  ✓ Glue: Database catalog created"
echo ""
echo "🎯 Next Step: Run 02-create-lambda-functions.sh"
echo "=================================================="
