#!/bin/bash

################################################################################
# AWS Data Analysis Platform - Master Deployment Script
# Runs all setup scripts in sequence
################################################################################

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}"
cat << 'EOF'
╔════════════════════════════════════════════════════════════════╗
║                                                                ║
║   AWS DATA ANALYSIS PLATFORM - AUTOMATED DEPLOYMENT           ║
║                                                                ║
║   🎯 Serverless | 🤖 AI-Powered | 💰 Cost-Optimized          ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}"
echo ""

# Configuration
REGION="eu-central-1"
ACCOUNT_ID="360783618622"

echo "📋 Deployment Configuration:"
echo "  Region: ${REGION}"
echo "  Account: ${ACCOUNT_ID}"
echo "  Timestamp: $(date)"
echo ""

# Check prerequisites
echo "🔍 Checking prerequisites..."

# Check AWS CLI
if ! command -v aws &> /dev/null; then
    echo -e "${RED}❌ AWS CLI not found. Please install it first.${NC}"
    exit 1
fi
echo -e "${GREEN}✓${NC} AWS CLI installed"

# Check jq
if ! command -v jq &> /dev/null; then
    echo -e "${YELLOW}⚠️  jq not found. Installing...${NC}"
    # In CloudShell, jq should be available, but just in case
    sudo yum install -y jq 2>/dev/null || echo "Please install jq manually"
fi
echo -e "${GREEN}✓${NC} jq installed"

# Verify AWS credentials
if aws sts get-caller-identity &> /dev/null; then
    CURRENT_ACCOUNT=$(aws sts get-caller-identity --query Account --output text)
    echo -e "${GREEN}✓${NC} AWS credentials valid"
    echo "  Current Account: ${CURRENT_ACCOUNT}"
    
    if [ "$CURRENT_ACCOUNT" != "$ACCOUNT_ID" ]; then
        echo -e "${YELLOW}⚠️  Warning: Current account (${CURRENT_ACCOUNT}) differs from configured (${ACCOUNT_ID})${NC}"
        read -p "Continue anyway? (y/n) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
else
    echo -e "${RED}❌ AWS credentials not configured properly${NC}"
    exit 1
fi

echo ""

# Confirm deployment
echo -e "${YELLOW}⚠️  This will create AWS resources that may incur costs.${NC}"
echo "Estimated monthly cost: $15-35"
echo ""
read -p "Proceed with deployment? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Deployment cancelled."
    exit 0
fi

echo ""
echo "=================================================="
echo "🚀 Starting Deployment..."
echo "=================================================="
echo ""

# Make all scripts executable
chmod +x 01-setup-foundation.sh
chmod +x 02-create-lambda-functions.sh
chmod +x 03-setup-api-gateway.sh
chmod +x 04-setup-monitoring.sh
chmod +x test-api.sh

################################################################################
# Phase 1: Foundation
################################################################################

echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  PHASE 1: Foundation Setup (S3, IAM, DynamoDB)${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo ""

if ./01-setup-foundation.sh; then
    echo -e "${GREEN}✅ Phase 1 Complete${NC}"
else
    echo -e "${RED}❌ Phase 1 Failed${NC}"
    exit 1
fi

echo ""
read -p "Press Enter to continue to Phase 2..."
echo ""

################################################################################
# Phase 2: Lambda Functions
################################################################################

echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  PHASE 2: Lambda Functions Deployment${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo ""

if ./02-create-lambda-functions.sh; then
    echo -e "${GREEN}✅ Phase 2 Complete${NC}"
else
    echo -e "${RED}❌ Phase 2 Failed${NC}"
    exit 1
fi

echo ""
read -p "Press Enter to continue to Phase 3..."
echo ""

################################################################################
# Phase 3: API Gateway
################################################################################

echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  PHASE 3: API Gateway Setup${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo ""

if ./03-setup-api-gateway.sh; then
    echo -e "${GREEN}✅ Phase 3 Complete${NC}"
else
    echo -e "${RED}❌ Phase 3 Failed${NC}"
    exit 1
fi

echo ""
read -p "Press Enter to continue to Phase 4..."
echo ""

################################################################################
# Phase 4: Monitoring
################################################################################

echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  PHASE 4: Monitoring & Alarms${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo ""

if ./04-setup-monitoring.sh; then
    echo -e "${GREEN}✅ Phase 4 Complete${NC}"
else
    echo -e "${YELLOW}⚠️  Phase 4 had warnings (this is OK)${NC}"
fi

echo ""
echo "=================================================="
echo "✅ DEPLOYMENT COMPLETE!"
echo "=================================================="
echo ""

# Load final configuration
CONFIG=$(cat /tmp/data-analysis-platform-config.json)
API_ENDPOINT=$(echo $CONFIG | jq -r '.api_endpoint')
DATA_BUCKET=$(echo $CONFIG | jq -r '.data_bucket')
FRONTEND_BUCKET=$(echo $CONFIG | jq -r '.frontend_bucket')

echo -e "${GREEN}🎉 Your Data Analysis Platform is ready!${NC}"
echo ""
echo "📋 Resource Summary:"
echo "  ✓ S3 Data Bucket: ${DATA_BUCKET}"
echo "  ✓ S3 Frontend Bucket: ${FRONTEND_BUCKET}"
echo "  ✓ API Endpoint: ${API_ENDPOINT}"
echo "  ✓ Lambda Functions: 3 deployed"
echo "  ✓ DynamoDB Tables: 2 created"
echo "  ✓ Glue Database: Ready"
echo "  ✓ CloudWatch: Monitoring enabled"
echo ""
echo "🔗 Quick Access URLs:"
echo "  API Console: https://eu-central-1.console.aws.amazon.com/apigateway"
echo "  Lambda Console: https://eu-central-1.console.aws.amazon.com/lambda"
echo "  S3 Console: https://s3.console.aws.amazon.com/s3/buckets/${DATA_BUCKET}"
echo "  CloudWatch Dashboard: https://eu-central-1.console.aws.amazon.com/cloudwatch"
echo ""
echo "🧪 Test Your Deployment:"
echo "  Run: ./test-api.sh"
echo ""
echo "📊 API Endpoints:"
echo "  Upload:  ${API_ENDPOINT}/upload"
echo "  Analyze: ${API_ENDPOINT}/analyze"
echo ""
echo "💰 Estimated Monthly Cost: $15-35"
echo ""
echo "🎯 Next Steps:"
echo "  1. Run ./test-api.sh to verify everything works"
echo "  2. Enable Bedrock in eu-central-1 (if not already)"
echo "  3. Build the React frontend"
echo "  4. Upload your data and start analyzing!"
echo ""
echo "📚 Documentation:"
echo "  See README.md for detailed usage instructions"
echo ""
echo "=================================================="

# Ask if user wants to run tests
echo ""
read -p "Would you like to run API tests now? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo ""
    ./test-api.sh
fi

echo ""
echo -e "${GREEN}✅ All done! Happy analyzing! 🎉${NC}"
echo ""
