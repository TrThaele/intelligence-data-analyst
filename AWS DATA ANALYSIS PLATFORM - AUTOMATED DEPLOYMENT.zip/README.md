# AWS Data Analysis Platform - Deployment Guide

## 🎯 Overview
This project creates a fully serverless, AI-powered data analysis platform on AWS that can:
- Accept file uploads (CSV, Excel, JSON)
- Process and transform data automatically
- Generate AI-powered insights using Amazon Bedrock
- Visualize results through a web dashboard

## 💰 Cost Estimate
**MVP Monthly Cost: $15-35**
- S3: ~$2
- Lambda: Free tier (~$0)
- API Gateway: ~$1
- DynamoDB: Free tier (~$0)
- Athena: Pay-per-query (~$1)
- Bedrock: ~$5-20 (depending on usage)
- CloudWatch: ~$3

## 🏗️ Architecture
```
Users → CloudFront → S3 (React Frontend)
                ↓
            API Gateway
                ↓
          Lambda Functions
                ↓
    S3 Data Lake (Raw → Processed)
                ↓
    Bedrock AI Analysis → DynamoDB Cache
                ↓
        QuickSight/Dashboard
```

## 📋 Prerequisites
1. AWS Account with access to eu-central-1 region
2. AWS CLI configured with appropriate credentials
3. Access to CloudShell (or terminal with AWS CLI)
4. Bedrock access enabled (optional for AI features)

## 🚀 Deployment Steps

### Step 1: Foundation Setup
```bash
# Make scripts executable
chmod +x *.sh

# Run foundation setup (S3, IAM, DynamoDB, Glue)
./01-setup-foundation.sh
```

**What this creates:**
- ✅ S3 buckets for data and frontend
- ✅ IAM roles for Lambda functions
- ✅ DynamoDB tables for metadata and caching
- ✅ Glue Data Catalog database

**Time: ~2 minutes**

### Step 2: Lambda Functions
```bash
# Create and deploy all Lambda functions
./02-create-lambda-functions.sh
```

**What this creates:**
- ✅ Upload Handler Lambda (processes API uploads)
- ✅ Data Processor Lambda (converts CSV to optimized format)
- ✅ AI Analyzer Lambda (generates insights with Bedrock)
- ✅ S3 event trigger for automatic processing

**Time: ~3 minutes**

### Step 3: API Gateway
```bash
# Set up REST API with endpoints
./03-setup-api-gateway.sh
```

**What this creates:**
- ✅ REST API with CORS enabled
- ✅ `/upload` endpoint for file uploads
- ✅ `/analyze` endpoint for AI analysis
- ✅ Production deployment

**Time: ~2 minutes**

### Step 4: Monitoring (Optional but Recommended)
```bash
# Configure CloudWatch monitoring
./04-setup-monitoring.sh
```

**What this creates:**
- ✅ CloudWatch Log Groups
- ✅ Alarms for errors and throttling
- ✅ Cost budget alerts
- ✅ Dashboard for metrics
- ✅ X-Ray tracing

**Time: ~1 minute**

## 🧪 Testing the Backend

After deployment, test your API:

```bash
# Run the test script
./test-api.sh
```

This will:
1. Upload a sample CSV file
2. Wait for processing
3. Request AI analysis
4. Display results

**Manual Test:**
```bash
# Get your API endpoint
CONFIG=$(cat /tmp/data-analysis-platform-config.json)
API_ENDPOINT=$(echo $CONFIG | jq -r '.api_endpoint')

# Test upload endpoint
curl -X POST ${API_ENDPOINT}/upload \
  -H "Content-Type: application/json" \
  -d '{
    "fileName": "test.csv",
    "fileType": "text/csv",
    "fileContent": "'"$(echo -n "name,age,city\nJohn,30,NYC\nJane,25,LA" | base64)"'"
  }'
```

## 🎨 Frontend Development (Next Phase)

Once the backend is working, you can build the React frontend:

```bash
# Frontend will be built in the next phase
# It will include:
# - File upload interface
# - Data preview
# - AI insights display
# - Interactive charts
```

## 📊 Accessing Your Resources

After deployment, access your resources:

1. **S3 Buckets:**
   ```bash
   aws s3 ls s3://data-analysis-platform-data-360783618622/
   ```

2. **DynamoDB Tables:**
   ```bash
   aws dynamodb scan --table-name data-analysis-platform-metadata --max-items 5
   ```

3. **CloudWatch Logs:**
   ```bash
   aws logs tail /aws/lambda/data-analysis-platform-upload-handler --follow
   ```

4. **API Gateway:**
   - Console: https://eu-central-1.console.aws.amazon.com/apigateway
   - Your API endpoint is saved in `/tmp/data-analysis-platform-config.json`

## 🔧 Configuration

All configuration is stored in:
```bash
/tmp/data-analysis-platform-config.json
```

View it:
```bash
cat /tmp/data-analysis-platform-config.json | jq .
```

## 🐛 Troubleshooting

### Lambda Execution Errors
```bash
# Check logs
aws logs tail /aws/lambda/data-analysis-platform-upload-handler --follow

# Test function directly
aws lambda invoke \
  --function-name data-analysis-platform-upload-handler \
  --payload '{"test": "data"}' \
  /tmp/response.json

cat /tmp/response.json
```

### IAM Permission Issues
```bash
# Verify role exists
aws iam get-role --role-name data-analysis-platform-lambda-upload-role

# Check attached policies
aws iam list-attached-role-policies \
  --role-name data-analysis-platform-lambda-upload-role
```

### S3 Access Issues
```bash
# Verify bucket exists
aws s3 ls s3://data-analysis-platform-data-360783618622/

# Check bucket policy
aws s3api get-bucket-policy \
  --bucket data-analysis-platform-data-360783618622
```

### API Gateway Issues
```bash
# Get API details
aws apigateway get-rest-apis --query 'items[?name==`data-analysis-platform-api`]'

# Test deployment
API_ID=$(aws apigateway get-rest-apis --query 'items[?name==`data-analysis-platform-api`].id' --output text)
aws apigateway get-deployments --rest-api-id $API_ID
```

## 🔐 Security Best Practices

1. **Enable encryption:** Already enabled on S3 buckets
2. **Least privilege IAM:** Roles have minimal required permissions
3. **CORS configured:** API Gateway only allows necessary origins
4. **Logging enabled:** CloudWatch captures all activity
5. **Secrets Management:** Use Secrets Manager for any credentials

## 💡 Next Steps

1. ✅ **Test the backend** with sample data
2. ⬜ **Enable Bedrock** for AI features (if not already enabled)
3. ⬜ **Build React frontend** for user interface
4. ⬜ **Add Cognito** for user authentication
5. ⬜ **Set up QuickSight** for advanced visualization
6. ⬜ **Configure custom domain** with Route 53

## 🧹 Cleanup (When Done)

To delete all resources and avoid charges:

```bash
# Delete Lambda functions
aws lambda delete-function --function-name data-analysis-platform-upload-handler
aws lambda delete-function --function-name data-analysis-platform-data-processor
aws lambda delete-function --function-name data-analysis-platform-ai-analyzer

# Delete API Gateway
API_ID=$(aws apigateway get-rest-apis --query 'items[?name==`data-analysis-platform-api`].id' --output text)
aws apigateway delete-rest-api --rest-api-id $API_ID

# Empty and delete S3 buckets
aws s3 rm s3://data-analysis-platform-data-360783618622 --recursive
aws s3 rb s3://data-analysis-platform-data-360783618622
aws s3 rm s3://data-analysis-platform-frontend-360783618622 --recursive
aws s3 rb s3://data-analysis-platform-frontend-360783618622

# Delete DynamoDB tables
aws dynamodb delete-table --table-name data-analysis-platform-metadata
aws dynamodb delete-table --table-name data-analysis-platform-ai-insights

# Delete IAM roles (detach policies first)
for ROLE in lambda-upload-role lambda-processor-role lambda-ai-role; do
  aws iam delete-role-policy --role-name data-analysis-platform-${ROLE} --policy-name S3AccessPolicy 2>/dev/null || true
  aws iam detach-role-policy --role-name data-analysis-platform-${ROLE} --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole 2>/dev/null || true
  aws iam delete-role --role-name data-analysis-platform-${ROLE}
done

# Delete Glue database
aws glue delete-database --name data-analysis-platform_catalog
```

## 📞 Support

For issues or questions:
1. Check CloudWatch Logs first
2. Review IAM permissions
3. Verify region is eu-central-1
4. Check the troubleshooting section above

## 📚 Additional Resources

- [AWS Lambda Documentation](https://docs.aws.amazon.com/lambda/)
- [API Gateway Documentation](https://docs.aws.amazon.com/apigateway/)
- [Amazon Bedrock Documentation](https://docs.aws.amazon.com/bedrock/)
- [S3 Best Practices](https://docs.aws.amazon.com/AmazonS3/latest/userguide/best-practices.html)

---

**Built with ❤️ for AWS CloudShell**
**Region: eu-central-1**
**Cost-Optimized | Serverless | AI-Powered**
