#!/bin/bash

################################################################################
# AWS Data Analysis Platform - Monitoring & CloudWatch Setup
# Phase 4: Configure CloudWatch Alarms and Dashboards
################################################################################

set -e

# Load configuration
if [ ! -f /tmp/data-analysis-platform-config.json ]; then
    echo "❌ Error: Configuration file not found."
    exit 1
fi

CONFIG=$(cat /tmp/data-analysis-platform-config.json)
REGION=$(echo $CONFIG | jq -r '.region')
ACCOUNT_ID=$(echo $CONFIG | jq -r '.account_id')
PROJECT_NAME=$(echo $CONFIG | jq -r '.project_name')

echo "=================================================="
echo "📊 Setting up Monitoring & Alarms"
echo "=================================================="
echo ""

################################################################################
# Create CloudWatch Log Groups (if not auto-created)
################################################################################

echo "📝 Ensuring CloudWatch Log Groups exist..."

for FUNCTION in upload-handler data-processor ai-analyzer; do
    aws logs create-log-group \
        --log-group-name "/aws/lambda/${PROJECT_NAME}-${FUNCTION}" \
        --region ${REGION} \
        2>/dev/null || echo "Log group already exists: ${FUNCTION}"
    
    # Set retention to 7 days to save costs
    aws logs put-retention-policy \
        --log-group-name "/aws/lambda/${PROJECT_NAME}-${FUNCTION}" \
        --retention-in-days 7 \
        --region ${REGION}
done

echo "✅ Log groups configured!"
echo ""

################################################################################
# Create SNS Topic for Alarms (Optional)
################################################################################

echo "📧 Creating SNS Topic for alerts..."

SNS_TOPIC_ARN=$(aws sns create-topic \
    --name ${PROJECT_NAME}-alerts \
    --region ${REGION} \
    --output text \
    --query 'TopicArn')

echo "SNS Topic: ${SNS_TOPIC_ARN}"
echo "⚠️  Subscribe to this topic to receive alerts:"
echo "   aws sns subscribe --topic-arn ${SNS_TOPIC_ARN} --protocol email --notification-endpoint YOUR_EMAIL@example.com"
echo ""

################################################################################
# Create CloudWatch Alarms
################################################################################

echo "⏰ Creating CloudWatch Alarms..."

# Alarm 1: Lambda Errors
aws cloudwatch put-metric-alarm \
    --alarm-name "${PROJECT_NAME}-lambda-errors" \
    --alarm-description "Alert when Lambda functions error" \
    --metric-name Errors \
    --namespace AWS/Lambda \
    --statistic Sum \
    --period 300 \
    --evaluation-periods 1 \
    --threshold 5 \
    --comparison-operator GreaterThanThreshold \
    --treat-missing-data notBreaching \
    --region ${REGION} \
    2>/dev/null || echo "Alarm already exists"

# Alarm 2: API Gateway 5XX Errors
if [ ! -z "$(echo $CONFIG | jq -r '.api_id')" ]; then
    API_ID=$(echo $CONFIG | jq -r '.api_id')
    
    aws cloudwatch put-metric-alarm \
        --alarm-name "${PROJECT_NAME}-api-5xx-errors" \
        --alarm-description "Alert on API Gateway 5XX errors" \
        --metric-name 5XXError \
        --namespace AWS/ApiGateway \
        --dimensions Name=ApiName,Value=${PROJECT_NAME}-api \
        --statistic Sum \
        --period 300 \
        --evaluation-periods 1 \
        --threshold 10 \
        --comparison-operator GreaterThanThreshold \
        --treat-missing-data notBreaching \
        --region ${REGION} \
        2>/dev/null || echo "Alarm already exists"
fi

# Alarm 3: DynamoDB Read/Write Throttling
aws cloudwatch put-metric-alarm \
    --alarm-name "${PROJECT_NAME}-dynamodb-throttles" \
    --alarm-description "Alert on DynamoDB throttling" \
    --metric-name UserErrors \
    --namespace AWS/DynamoDB \
    --statistic Sum \
    --period 300 \
    --evaluation-periods 1 \
    --threshold 10 \
    --comparison-operator GreaterThanThreshold \
    --region ${REGION} \
    2>/dev/null || echo "Alarm already exists"

echo "✅ CloudWatch Alarms created!"
echo ""

################################################################################
# Create Cost Budget Alert
################################################################################

echo "💰 Setting up Cost Budget..."

cat > /tmp/budget-definition.json << EOF
{
    "BudgetName": "${PROJECT_NAME}-monthly-budget",
    "BudgetType": "COST",
    "TimeUnit": "MONTHLY",
    "BudgetLimit": {
        "Amount": "50",
        "Unit": "USD"
    },
    "CostFilters": {},
    "CostTypes": {
        "IncludeTax": true,
        "IncludeSubscription": true,
        "UseBlended": false,
        "IncludeRefund": false,
        "IncludeCredit": false,
        "IncludeUpfront": true,
        "IncludeRecurring": true,
        "IncludeOtherSubscription": true,
        "IncludeSupport": true,
        "IncludeDiscount": true,
        "UseAmortized": false
    }
}
EOF

# Note: Budget API requires specific permissions and may not work in all accounts
aws budgets create-budget \
    --account-id ${ACCOUNT_ID} \
    --budget file:///tmp/budget-definition.json \
    --region us-east-1 \
    2>/dev/null || echo "⚠️  Budget creation requires additional permissions or may already exist"

echo "✅ Cost monitoring configured!"
echo ""

################################################################################
# Create CloudWatch Dashboard
################################################################################

echo "📊 Creating CloudWatch Dashboard..."

DASHBOARD_BODY=$(cat << 'EOF'
{
    "widgets": [
        {
            "type": "metric",
            "properties": {
                "metrics": [
                    [ "AWS/Lambda", "Invocations", { "stat": "Sum" } ],
                    [ ".", "Errors", { "stat": "Sum" } ],
                    [ ".", "Duration", { "stat": "Average" } ]
                ],
                "period": 300,
                "stat": "Average",
                "region": "REGION_PLACEHOLDER",
                "title": "Lambda Metrics",
                "yAxis": {
                    "left": {
                        "showUnits": false
                    }
                }
            }
        },
        {
            "type": "metric",
            "properties": {
                "metrics": [
                    [ "AWS/ApiGateway", "Count", { "stat": "Sum" } ],
                    [ ".", "4XXError", { "stat": "Sum" } ],
                    [ ".", "5XXError", { "stat": "Sum" } ],
                    [ ".", "Latency", { "stat": "Average" } ]
                ],
                "period": 300,
                "stat": "Average",
                "region": "REGION_PLACEHOLDER",
                "title": "API Gateway Metrics"
            }
        },
        {
            "type": "metric",
            "properties": {
                "metrics": [
                    [ "AWS/DynamoDB", "ConsumedReadCapacityUnits", { "stat": "Sum" } ],
                    [ ".", "ConsumedWriteCapacityUnits", { "stat": "Sum" } ],
                    [ ".", "UserErrors", { "stat": "Sum" } ]
                ],
                "period": 300,
                "stat": "Average",
                "region": "REGION_PLACEHOLDER",
                "title": "DynamoDB Metrics"
            }
        },
        {
            "type": "log",
            "properties": {
                "query": "SOURCE '/aws/lambda/PROJECT_NAME-upload-handler'\n| fields @timestamp, @message\n| sort @timestamp desc\n| limit 20",
                "region": "REGION_PLACEHOLDER",
                "title": "Recent Lambda Logs"
            }
        }
    ]
}
EOF
)

# Replace placeholders
DASHBOARD_BODY=$(echo "$DASHBOARD_BODY" | sed "s/REGION_PLACEHOLDER/${REGION}/g" | sed "s/PROJECT_NAME/${PROJECT_NAME}/g")

aws cloudwatch put-dashboard \
    --dashboard-name "${PROJECT_NAME}-dashboard" \
    --dashboard-body "$DASHBOARD_BODY" \
    --region ${REGION}

echo "✅ Dashboard created: ${PROJECT_NAME}-dashboard"
echo ""

################################################################################
# Enable AWS X-Ray Tracing (Optional but useful)
################################################################################

echo "🔍 Enabling X-Ray Tracing..."

for FUNCTION in upload-handler data-processor ai-analyzer; do
    aws lambda update-function-configuration \
        --function-name ${PROJECT_NAME}-${FUNCTION} \
        --tracing-config Mode=Active \
        --region ${REGION} \
        > /dev/null 2>&1 || echo "X-Ray already enabled: ${FUNCTION}"
done

echo "✅ X-Ray tracing enabled!"
echo ""

echo "=================================================="
echo "✅ Monitoring Setup Complete!"
echo "=================================================="
echo ""
echo "📋 Summary:"
echo "  ✓ CloudWatch Log Groups (7-day retention)"
echo "  ✓ CloudWatch Alarms for errors and throttling"
echo "  ✓ Cost Budget ($50/month alert)"
echo "  ✓ CloudWatch Dashboard: ${PROJECT_NAME}-dashboard"
echo "  ✓ X-Ray Tracing enabled on all Lambda functions"
echo ""
echo "🔗 Quick Links:"
echo "  Dashboard: https://${REGION}.console.aws.amazon.com/cloudwatch/home?region=${REGION}#dashboards:name=${PROJECT_NAME}-dashboard"
echo "  Logs: https://${REGION}.console.aws.amazon.com/cloudwatch/home?region=${REGION}#logsV2:log-groups"
echo "  Alarms: https://${REGION}.console.aws.amazon.com/cloudwatch/home?region=${REGION}#alarmsV2:"
echo ""
echo "🎯 Backend Complete! Next: Test the API or build the frontend"
echo "=================================================="
