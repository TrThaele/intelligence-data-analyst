# 🚀 Quick Start Guide - AWS Data Analysis Platform

## ⚡ Super Fast Deployment (15 minutes)

### Step 1: Download Files
Download all the files from this folder to your local machine.

### Step 2: Open AWS CloudShell
1. Go to AWS Console: https://console.aws.amazon.com
2. Make sure you're in **eu-central-1** region
3. Click the CloudShell icon (terminal icon in top right)
4. Wait for CloudShell to initialize

### Step 3: Upload Files
In CloudShell:
```bash
# Create project directory
mkdir -p data-analysis-platform
cd data-analysis-platform
```

Then click **Actions → Upload Files** and upload all .sh files

### Step 4: Run Master Deployment
```bash
# Make the master script executable
chmod +x deploy-all.sh

# Run it!
./deploy-all.sh
```

That's it! The script will:
- ✅ Create all AWS resources
- ✅ Deploy Lambda functions
- ✅ Set up API Gateway
- ✅ Configure monitoring
- ✅ Run tests

**Time: ~8-10 minutes**

---

## 📱 Manual Step-by-Step (if you prefer)

### Option 1: All at Once
```bash
./deploy-all.sh
```

### Option 2: One Phase at a Time
```bash
# Phase 1: Foundation
./01-setup-foundation.sh

# Phase 2: Lambda Functions
./02-create-lambda-functions.sh

# Phase 3: API Gateway
./03-setup-api-gateway.sh

# Phase 4: Monitoring (optional)
./04-setup-monitoring.sh

# Test everything
./test-api.sh
```

---

## 🎨 View the Architecture

1. Go to https://app.diagrams.net
2. Click **File → Open From → Device**
3. Select `aws-data-platform-architecture.drawio`
4. Explore the complete architecture!

---

## 🧪 Testing

After deployment:
```bash
./test-api.sh
```

This will:
- Upload a sample CSV
- Process it automatically
- Generate AI insights
- Show you the results

---

## 📊 Access Your Resources

### API Endpoint
```bash
cat /tmp/data-analysis-platform-config.json | jq -r '.api_endpoint'
```

### View Files in S3
```bash
aws s3 ls s3://data-analysis-platform-data-360783618622/raw/ --recursive
```

### Check Lambda Logs
```bash
aws logs tail /aws/lambda/data-analysis-platform-upload-handler --follow
```

### View DynamoDB Data
```bash
aws dynamodb scan --table-name data-analysis-platform-metadata --max-items 5
```

---

## 🐛 Troubleshooting

### "Permission Denied" on Scripts
```bash
chmod +x *.sh
```

### API Not Working
```bash
# Check Lambda logs
aws logs tail /aws/lambda/data-analysis-platform-upload-handler --follow

# Verify API Gateway
aws apigateway get-rest-apis --query 'items[?name==`data-analysis-platform-api`]'
```

### Bedrock Not Working
Enable Bedrock in eu-central-1:
1. Go to AWS Console → Bedrock
2. Click "Get Started"
3. Request model access for Claude models

---

## 💰 Cost Tracking

Set up billing alerts:
```bash
# This is done automatically in Phase 4
# Check your budget at:
# https://console.aws.amazon.com/billing/home#/budgets
```

---

## 🧹 Cleanup (Delete Everything)

When you're done:
```bash
# Delete Lambda functions
for FUNC in upload-handler data-processor ai-analyzer; do
  aws lambda delete-function --function-name data-analysis-platform-${FUNC}
done

# Delete API Gateway
API_ID=$(aws apigateway get-rest-apis --query 'items[?name==`data-analysis-platform-api`].id' --output text)
aws apigateway delete-rest-api --rest-api-id $API_ID

# Empty and delete S3 buckets
aws s3 rm s3://data-analysis-platform-data-360783618622 --recursive
aws s3 rb s3://data-analysis-platform-data-360783618622
aws s3 rm s3://data-analysis-platform-frontend-360783618622 --recursive
aws s3 rb s3://data-analysis-platform-frontend-360783618622

# Delete DynamoDB tables
aws dynamodb delete-table --table-name data-analysis-platform-metadata
aws dynamodb delete-table --table-name data-analysis-platform-ai-insights

# Delete Glue database
aws glue delete-database --name data-analysis-platform_catalog
```

Full cleanup script in README.md

---

## 🎯 What's Next?

After backend is working:

1. **Enable Bedrock** (if AI analysis fails)
2. **Build React Frontend** - We'll do this next!
3. **Add Authentication** - Cognito integration
4. **Custom Domain** - Route 53 + CloudFront
5. **Data Visualization** - QuickSight dashboards

---

## 📞 Need Help?

Check these in order:
1. CloudWatch Logs
2. IAM Role permissions
3. README.md troubleshooting section
4. AWS Service quotas

---

**Built for: Clowdy**
**Region: eu-central-1**
**Cost: $15-35/month**
**Time to Deploy: 10 minutes**

🎉 **Happy Building!**
