#!/bin/bash

################################################################################
# AWS Data Analysis Platform - API Test Script
# Tests all endpoints and verifies functionality
################################################################################

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "=================================================="
echo "🧪 Testing Data Analysis Platform API"
echo "=================================================="
echo ""

# Load configuration
if [ ! -f /tmp/data-analysis-platform-config.json ]; then
    echo -e "${RED}❌ Error: Configuration file not found.${NC}"
    echo "Please run 01-setup-foundation.sh and 03-setup-api-gateway.sh first."
    exit 1
fi

CONFIG=$(cat /tmp/data-analysis-platform-config.json)
API_ENDPOINT=$(echo $CONFIG | jq -r '.api_endpoint')
DATA_BUCKET=$(echo $CONFIG | jq -r '.data_bucket')

if [ -z "$API_ENDPOINT" ] || [ "$API_ENDPOINT" == "null" ]; then
    echo -e "${RED}❌ Error: API endpoint not found in configuration.${NC}"
    echo "Please run 03-setup-api-gateway.sh first."
    exit 1
fi

echo -e "${GREEN}✓ Configuration loaded${NC}"
echo "API Endpoint: ${API_ENDPOINT}"
echo ""

################################################################################
# Test 1: Health Check (API Gateway)
################################################################################

echo "📡 Test 1: API Gateway Health Check"
echo "-----------------------------------"

HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" ${API_ENDPOINT}/upload -X OPTIONS)

if [ "$HTTP_CODE" == "200" ]; then
    echo -e "${GREEN}✓ PASSED${NC} - API Gateway is responding (HTTP ${HTTP_CODE})"
else
    echo -e "${RED}✗ FAILED${NC} - API Gateway not responding properly (HTTP ${HTTP_CODE})"
fi
echo ""

################################################################################
# Test 2: Upload Endpoint
################################################################################

echo "📤 Test 2: File Upload"
echo "-----------------------------------"

# Create sample CSV data
SAMPLE_CSV="name,age,city,salary
John Doe,30,New York,75000
Jane Smith,25,Los Angeles,65000
Bob Johnson,35,Chicago,80000
Alice Williams,28,Houston,70000
Charlie Brown,32,Phoenix,72000"

# Base64 encode the CSV
CSV_BASE64=$(echo -n "$SAMPLE_CSV" | base64)

# Prepare JSON payload
UPLOAD_PAYLOAD=$(cat <<EOF
{
  "fileName": "test-data.csv",
  "fileType": "text/csv",
  "fileContent": "${CSV_BASE64}"
}
EOF
)

echo "Uploading test CSV file..."
UPLOAD_RESPONSE=$(curl -s -X POST ${API_ENDPOINT}/upload \
  -H "Content-Type: application/json" \
  -d "$UPLOAD_PAYLOAD")

echo "Response: ${UPLOAD_RESPONSE}"

# Check if upload was successful
UPLOAD_ID=$(echo $UPLOAD_RESPONSE | jq -r '.upload_id')

if [ "$UPLOAD_ID" != "null" ] && [ ! -z "$UPLOAD_ID" ]; then
    echo -e "${GREEN}✓ PASSED${NC} - File uploaded successfully"
    echo "  Upload ID: ${UPLOAD_ID}"
    S3_KEY=$(echo $UPLOAD_RESPONSE | jq -r '.s3_key')
    echo "  S3 Key: ${S3_KEY}"
    FILE_HASH=$(echo $UPLOAD_RESPONSE | jq -r '.file_hash')
    echo "  File Hash: ${FILE_HASH}"
else
    echo -e "${RED}✗ FAILED${NC} - Upload failed"
    echo "Response: ${UPLOAD_RESPONSE}"
fi
echo ""

################################################################################
# Test 3: Verify S3 Storage
################################################################################

echo "📦 Test 3: S3 Storage Verification"
echo "-----------------------------------"

if [ ! -z "$S3_KEY" ] && [ "$S3_KEY" != "null" ]; then
    echo "Checking if file exists in S3..."
    
    if aws s3 ls s3://${DATA_BUCKET}/${S3_KEY} > /dev/null 2>&1; then
        echo -e "${GREEN}✓ PASSED${NC} - File found in S3"
        
        # Get file size
        FILE_SIZE=$(aws s3 ls s3://${DATA_BUCKET}/${S3_KEY} | awk '{print $3}')
        echo "  File size: ${FILE_SIZE} bytes"
    else
        echo -e "${RED}✗ FAILED${NC} - File not found in S3"
    fi
else
    echo -e "${YELLOW}⊘ SKIPPED${NC} - No S3 key from upload test"
fi
echo ""

################################################################################
# Test 4: Wait for Processing
################################################################################

echo "⏳ Test 4: Data Processing"
echo "-----------------------------------"
echo "Waiting for Lambda processor to convert file (15 seconds)..."
sleep 15

if [ ! -z "$S3_KEY" ] && [ "$S3_KEY" != "null" ]; then
    PROCESSED_KEY=$(echo $S3_KEY | sed 's/raw/processed/')
    
    if aws s3 ls s3://${DATA_BUCKET}/${PROCESSED_KEY} > /dev/null 2>&1; then
        echo -e "${GREEN}✓ PASSED${NC} - File processed successfully"
        echo "  Processed key: ${PROCESSED_KEY}"
    else
        echo -e "${YELLOW}⊘ INCONCLUSIVE${NC} - Processed file not found yet (may need more time)"
        echo "  Expected: ${PROCESSED_KEY}"
    fi
else
    echo -e "${YELLOW}⊘ SKIPPED${NC} - No file to process"
fi
echo ""

################################################################################
# Test 5: AI Analysis Endpoint
################################################################################

echo "🤖 Test 5: AI Analysis"
echo "-----------------------------------"

if [ ! -z "$S3_KEY" ] && [ "$S3_KEY" != "null" ]; then
    ANALYZE_PAYLOAD=$(cat <<EOF
{
  "s3_key": "${PROCESSED_KEY}",
  "upload_id": "${UPLOAD_ID}"
}
EOF
)
    
    echo "Requesting AI analysis..."
    ANALYZE_RESPONSE=$(curl -s -X POST ${API_ENDPOINT}/analyze \
      -H "Content-Type: application/json" \
      -d "$ANALYZE_PAYLOAD")
    
    echo "Response: ${ANALYZE_RESPONSE}" | jq '.' 2>/dev/null || echo "${ANALYZE_RESPONSE}"
    
    # Check if analysis was successful
    INSIGHTS=$(echo $ANALYZE_RESPONSE | jq -r '.insights' 2>/dev/null)
    
    if [ ! -z "$INSIGHTS" ] && [ "$INSIGHTS" != "null" ]; then
        echo -e "${GREEN}✓ PASSED${NC} - AI analysis completed"
        echo "Insights:"
        echo $ANALYZE_RESPONSE | jq '.insights' 2>/dev/null || echo "Unable to parse insights"
    else
        ERROR=$(echo $ANALYZE_RESPONSE | jq -r '.error' 2>/dev/null)
        if [ ! -z "$ERROR" ] && [ "$ERROR" != "null" ]; then
            echo -e "${YELLOW}⊘ PARTIAL${NC} - Analysis endpoint working but Bedrock may not be enabled"
            echo "  Error: ${ERROR}"
        else
            echo -e "${RED}✗ FAILED${NC} - Analysis failed"
        fi
    fi
else
    echo -e "${YELLOW}⊘ SKIPPED${NC} - No file to analyze"
fi
echo ""

################################################################################
# Test 6: DynamoDB Metadata Check
################################################################################

echo "🗄️  Test 6: DynamoDB Metadata"
echo "-----------------------------------"

METADATA_TABLE=$(echo $CONFIG | jq -r '.metadata_table')

if [ ! -z "$UPLOAD_ID" ] && [ "$UPLOAD_ID" != "null" ]; then
    echo "Checking metadata in DynamoDB..."
    
    METADATA=$(aws dynamodb query \
        --table-name ${METADATA_TABLE} \
        --key-condition-expression "upload_id = :uid" \
        --expression-attribute-values "{\":uid\":{\"S\":\"${UPLOAD_ID}\"}}" \
        --output json 2>/dev/null)
    
    ITEM_COUNT=$(echo $METADATA | jq '.Items | length')
    
    if [ "$ITEM_COUNT" -gt 0 ]; then
        echo -e "${GREEN}✓ PASSED${NC} - Metadata found in DynamoDB"
        echo "  Items: ${ITEM_COUNT}"
    else
        echo -e "${YELLOW}⊘ INCONCLUSIVE${NC} - Metadata not found yet"
    fi
else
    echo -e "${YELLOW}⊘ SKIPPED${NC} - No upload ID to check"
fi
echo ""

################################################################################
# Test 7: Lambda Logs Check
################################################################################

echo "📝 Test 7: Lambda Execution Logs"
echo "-----------------------------------"
echo "Recent logs from Upload Handler:"

aws logs tail /aws/lambda/data-analysis-platform-upload-handler \
    --since 5m \
    --format short \
    --max-items 5 \
    2>/dev/null || echo "Unable to fetch logs (may not exist yet)"

echo ""

################################################################################
# Summary
################################################################################

echo "=================================================="
echo "📊 Test Summary"
echo "=================================================="
echo ""
echo "Backend Components Status:"
echo "  ✓ API Gateway: Working"
echo "  ✓ Lambda Functions: Deployed"
echo "  ✓ S3 Buckets: Available"
echo "  ✓ DynamoDB Tables: Ready"
echo ""
echo "API Endpoints:"
echo "  Upload:  ${API_ENDPOINT}/upload"
echo "  Analyze: ${API_ENDPOINT}/analyze"
echo ""
echo "🔗 Useful Commands:"
echo ""
echo "View all files in S3:"
echo "  aws s3 ls s3://${DATA_BUCKET}/raw/ --recursive"
echo ""
echo "Check Lambda logs:"
echo "  aws logs tail /aws/lambda/data-analysis-platform-upload-handler --follow"
echo ""
echo "View DynamoDB items:"
echo "  aws dynamodb scan --table-name ${METADATA_TABLE} --max-items 5"
echo ""
echo "🎯 Next Steps:"
echo "  1. If Bedrock analysis failed, enable Bedrock in eu-central-1"
echo "  2. Build the React frontend"
echo "  3. Upload real data and test workflows"
echo ""
echo "=================================================="
